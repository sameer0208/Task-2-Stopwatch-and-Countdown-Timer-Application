let timer;
let isRunning = false;
let startTime;
let elapsedTime = 0;
let laps = [];

document.getElementById('startStop').addEventListener('click', function() {
    if (isRunning) {
        clearInterval(timer);
        this.textContent = 'Resume';
    } else {
        startTime = Date.now() - elapsedTime;
        timer = setInterval(updateTime, 10);
        this.textContent = 'Pause';
    }
    isRunning = !isRunning;
});

document.getElementById('reset').addEventListener('click', function() {
    clearInterval(timer);
    isRunning = false;
    document.getElementById('startStop').textContent = 'Start';
    elapsedTime = 0;
    updateTime();
    document.getElementById('laps').innerHTML = '';
    laps = [];
});

document.getElementById('lap').addEventListener('click', function() {
    if (isRunning) {
        laps.push(elapsedTime);
        displayLaps();
    }
});

function updateTime() {
    if (isRunning) {
        elapsedTime = Date.now() - startTime;
    }
    const milliseconds = Math.floor((elapsedTime % 1000) / 10);
    const seconds = Math.floor((elapsedTime / 1000) % 60);
    const minutes = Math.floor((elapsedTime / (1000 * 60)) % 60);
    const hours = Math.floor((elapsedTime / (1000 * 60 * 60)) % 24);

    document.getElementById('hours').textContent = pad(hours);
    document.getElementById('minutes').textContent = pad(minutes);
    document.getElementById('seconds').textContent = pad(seconds);
    document.getElementById('milliseconds').textContent = pad(milliseconds);
}

function pad(number) {
    return number < 10 ? '0' + number : number;
}

function displayLaps() {
    const lapsContainer = document.getElementById('laps');
    lapsContainer.innerHTML = '';
    let lastTime = 0;

    laps.forEach((lap, index) => {
        const lapElement = document.createElement('li');
        const lapTime = lap - lastTime;
        const totalTime = lap;
        lastTime = lap;

        lapElement.textContent = `Lap ${index + 1}: Split ${formatTime(lapTime)} - Total ${formatTime(totalTime)}`;
        lapsContainer.appendChild(lapElement);
    });
}

function formatTime(time) {
    const milliseconds = Math.floor((time % 1000) / 10);
    const seconds = Math.floor((time / 1000) % 60);
    const minutes = Math.floor((time / (1000 * 60)) % 60);
    const hours = Math.floor((time / (1000 * 60 * 60)) % 24);

    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}:${pad(milliseconds)}`;
}

let countdownTimer;
let countdownTime;
let remainingTime;
let isCountdownRunning = false;

const countdownHoursInput = document.getElementById('countdownHours');
const countdownMinutesInput = document.getElementById('countdownMinutes');
const countdownSecondsInput = document.getElementById('countdownSeconds');

const startCountdownButton = document.getElementById('startCountdown');
const pauseCountdownButton = document.getElementById('pauseCountdown');
const resetCountdownButton = document.getElementById('resetCountdown');

countdownHoursInput.addEventListener('input', toggleCountdownButtons);
countdownMinutesInput.addEventListener('input', toggleCountdownButtons);
countdownSecondsInput.addEventListener('input', toggleCountdownButtons);

startCountdownButton.addEventListener('click', startCountdown);
pauseCountdownButton.addEventListener('click', pauseResumeCountdown);
resetCountdownButton.addEventListener('click', resetCountdown);

function toggleCountdownButtons() {
    const hours = parseInt(countdownHoursInput.value) || 0;
    const minutes = parseInt(countdownMinutesInput.value) || 0;
    const seconds = parseInt(countdownSecondsInput.value) || 0;
    const totalSeconds = hours * 3600 + minutes * 60 + seconds;

    startCountdownButton.disabled = totalSeconds === 0;
    pauseCountdownButton.disabled = true;
    resetCountdownButton.disabled = true;
}

function startCountdown() {
    if (countdownTimer) {
        clearInterval(countdownTimer);
    }

    const hours = parseInt(countdownHoursInput.value) || 0;
    const minutes = parseInt(countdownMinutesInput.value) || 0;
    const seconds = parseInt(countdownSecondsInput.value) || 0;
    countdownTime = hours * 3600 + minutes * 60 + seconds;
    remainingTime = countdownTime;

    countdownTimer = setInterval(updateCountdown, 1000);
    isCountdownRunning = true;

    startCountdownButton.disabled = true;
    pauseCountdownButton.disabled = false;
    pauseCountdownButton.textContent = 'Pause';
    resetCountdownButton.disabled = false;
}

function pauseResumeCountdown() {
    if (pauseCountdownButton.textContent === 'Pause') {
        clearInterval(countdownTimer);
        pauseCountdownButton.textContent = 'Resume';
        isCountdownRunning = false;
    } else {
        countdownTimer = setInterval(updateCountdown, 1000);
        pauseCountdownButton.textContent = 'Pause';
        isCountdownRunning = true;
    }
}

function resetCountdown() {
    clearInterval(countdownTimer);
    countdownTimer = null;
    isCountdownRunning = false;

    countdownHoursInput.value = '';
    countdownMinutesInput.value = '';
    countdownSecondsInput.value = '';

    document.getElementById('countdownHoursDisplay').textContent = '00';
    document.getElementById('countdownMinutesDisplay').textContent = '00';
    document.getElementById('countdownSecondsDisplay').textContent = '00';

    startCountdownButton.disabled = true;
    pauseCountdownButton.disabled = true;
    resetCountdownButton.disabled = true;
}

function updateCountdown() {
    if (remainingTime <= 0) {
        clearInterval(countdownTimer);
        countdownTimer = null;
        isCountdownRunning = false;
        return;
    }

    remainingTime--;

    const hours = Math.floor(remainingTime / 3600);
    const minutes = Math.floor((remainingTime % 3600) / 60);
    const seconds = remainingTime % 60;

    document.getElementById('countdownHoursDisplay').textContent = hours < 10 ? '0' + hours : hours;
    document.getElementById('countdownMinutesDisplay').textContent = minutes < 10 ? '0' + minutes : minutes;
    document.getElementById('countdownSecondsDisplay').textContent = seconds < 10 ? '0' + seconds : seconds;

    // If countdown reaches zero, disable all buttons and reset input fields
    if (remainingTime <= 0) {
        resetCountdown();
    }
}

// Initially disable all buttons
toggleCountdownButtons();

function updateClock() {
    const clock = document.getElementById('clock');
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    clock.textContent = `🕒${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

function pad(number) {
    return number < 10 ? '0' + number : number;
}

setInterval(updateClock, 1000);
updateClock(); // Initial call to set the clock immediately
